﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    class History
    {
        public int Hist_ID { get; set; }
        public string Hist_Action { get; set; }
        public string Hist_Value { get; set; }
    }
}
